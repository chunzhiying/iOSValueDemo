//
//  WebViewController.m
//  HybridTest
//
//  Created by 陈智颖 on 15/3/25.
//  Copyright (c) 2015年 chenzy. All rights reserved.
//

#import "WebViewController.h"

@interface WebViewController (){
    
    __weak IBOutlet UIWebView *_webView;
}

@end

@implementation WebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _webView.delegate = self;
    
    NSString* path = [[NSBundle mainBundle] pathForResource:@"web" ofType:@"html"];
    [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:path]]];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)return:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)showAlert{
    NSLog(@"JS回调OC");
}

#pragma mark - webViewDelegate
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    //调JS方法
    [_webView stringByEvaluatingJavaScriptFromString:@"OCCall()"];
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    if (navigationType == UIWebViewNavigationTypeOther) {
        //把URL截取成要调用的方法名
        NSString* str = [[request.URL.absoluteString componentsSeparatedByString:@"/"] lastObject];
        SEL selector = NSSelectorFromString(str);
        if ([self respondsToSelector:selector]) {
            [self performSelector:selector withObject:nil];
            return NO;
        }
        
    }
    return YES;
}

@end
