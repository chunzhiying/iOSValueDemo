//
//  MessageObject.h
//  IMDemo
//
//  Created by chenzy on 15/4/24.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface MessageObject : NSObject

@property(nonatomic,strong)NSString* text;
@property(nonatomic) BOOL isSend;
@property(nonatomic,strong)UIImage* image;

@end
