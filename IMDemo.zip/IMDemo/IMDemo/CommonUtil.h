//
//  CommonUtil.h
//  IMDemo
//
//  Created by chenzy on 15/4/24.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CommonUtil : NSObject

+(float)figrueStringHeight:(NSString*)str withSize:(CGSize)size;

+(UIImage*)resizeImage:(UIImage *)image;

@end
