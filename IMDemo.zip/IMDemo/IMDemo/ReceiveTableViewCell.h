//
//  ReceiveTableViewCell.h
//  IMDemo
//
//  Created by chenzy on 15/4/24.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseTableViewCell.h"

@interface ReceiveTableViewCell : BaseTableViewCell

@end
