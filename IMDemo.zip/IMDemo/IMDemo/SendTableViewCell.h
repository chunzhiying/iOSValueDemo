//
//  SendTableViewCell.h
//  IMDemo
//
//  Created by chenzy on 15/4/24.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseTableViewCell.h"

@interface SendTableViewCell : BaseTableViewCell
@property (weak, nonatomic) IBOutlet UIView *portrait;
@property (weak, nonatomic) IBOutlet UILabel *content;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentHeight;

@property (weak, nonatomic) IBOutlet UIImageView *image;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imageWidth;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *imageHeight;


@end
