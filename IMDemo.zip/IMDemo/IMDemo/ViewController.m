//
//  ViewController.m
//  IMDemo
//
//  Created by chenzy on 15/4/24.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "ViewController.h"
#import "SendTableViewCell.h"
#import "ReceiveTableViewCell.h"
#import "MessageObject.h"
#import "CommonUtil.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationBarDelegate>{
    

    IBOutlet UITapGestureRecognizer *_bgTapGesture;
    __weak IBOutlet NSLayoutConstraint *_bottomViewDistance;
    __weak IBOutlet NSLayoutConstraint *_textFieldHeight;
    __weak IBOutlet UITextField *_textField;
    __weak IBOutlet UITableView *_tableView;
    
    NSMutableArray* _contentAry;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _contentAry = [NSMutableArray new];
    [_tableView addGestureRecognizer:_bgTapGesture];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillAppear:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillDisappear:) name:UIKeyboardWillHideNotification object:nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Notification
-(void)keyboardWillAppear:(NSNotification*)notification{
    NSValue *keyboardFrameValue = notification.userInfo[UIKeyboardFrameEndUserInfoKey];
    NSNumber *keyboardAnimationDuration = notification.userInfo[UIKeyboardAnimationDurationUserInfoKey];
    NSNumber *keyboardAnimationCurveUserInfo = notification.userInfo[UIKeyboardAnimationCurveUserInfoKey];
    CGRect keyboardFrame = [keyboardFrameValue CGRectValue];
    CGFloat height = CGRectGetHeight(keyboardFrame);
    
    _bottomViewDistance.constant = height;
    [UIView animateWithDuration:keyboardAnimationDuration.doubleValue
                          delay:0
                        options:keyboardAnimationCurveUserInfo.integerValue
                     animations:^{
                         [self.view layoutIfNeeded];
                     } completion:nil];
    if (_contentAry.count>0) {
        NSIndexPath* ipath = [NSIndexPath indexPathForRow:_contentAry.count - 1 inSection:0];
        [_tableView scrollToRowAtIndexPath: ipath atScrollPosition: UITableViewScrollPositionBottom animated: NO];
    }
}

-(void)keyboardWillDisappear:(NSNotification*)notification{
    NSNumber *keyboardAnimationDuration = notification.userInfo[UIKeyboardAnimationDurationUserInfoKey];
    NSNumber *keyboardAnimationCurveUserInfo = notification.userInfo[UIKeyboardAnimationCurveUserInfoKey];
    
    _bottomViewDistance.constant = 0;
    [UIView animateWithDuration:keyboardAnimationDuration.doubleValue
                          delay:0
                        options:keyboardAnimationCurveUserInfo.integerValue
                     animations:^{
                         [self.view layoutIfNeeded];
                     } completion:nil];
}

#pragma mark - TextField Delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (textField.text.length == 0) {
        return YES;
    }
    MessageObject* object = [[MessageObject alloc] init];
    object.text = textField.text;
    object.isSend = YES;
    object.image = nil;
    [_contentAry addObject:object];
    [self addCells];
    _textField.text = @"";
    return YES;
}

#pragma mark - Action
- (IBAction)clickSmileBtn:(id)sender {
}

- (IBAction)clickPhotoBtn:(id)sender {
    UIImagePickerController *pick = [[UIImagePickerController alloc] init];
    pick.delegate = self;
    pick.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    [self presentViewController:pick animated:YES completion:nil];
}

- (IBAction)backgroundTap:(id)sender {
    [_textField resignFirstResponder];
}

#pragma mark - Image Picker delegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo{
    MessageObject *object = [[MessageObject alloc] init];
    object.image = [CommonUtil resizeImage:image];
    [_contentAry addObject:object];
    [self addCells];
    [picker dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - TableView delegate
-(void)addCells{
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:_contentAry.count-1 inSection:0];
    [_tableView beginUpdates];
    [_tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    [_tableView endUpdates];
    [_tableView scrollToRowAtIndexPath: indexPath atScrollPosition: UITableViewScrollPositionBottom animated: YES];

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    MessageObject *object = (MessageObject*)[_contentAry objectAtIndex:indexPath.row];
    if (object.image) {
        return object.image.size.height+20;
    }
    float height = [CommonUtil figrueStringHeight:object.text withSize:CGSizeMake(200, 100)];
    return height>70?height+20:70;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _contentAry.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MessageObject* messageObj = (MessageObject*)[_contentAry objectAtIndex:indexPath.row];
    if (messageObj.isSend) {
        SendTableViewCell *sendCell = [tableView dequeueReusableCellWithIdentifier:@"sendCell"];
        sendCell.selectionStyle = UITableViewCellSelectionStyleNone;
        if (messageObj.image) {
            sendCell.image.image = messageObj.image;
            sendCell.imageHeight.constant = messageObj.image.size.height;
            sendCell.imageWidth.constant = messageObj.image.size.width;
            sendCell.image.hidden = NO;
            return sendCell;
        }
        sendCell.content.text = messageObj.text;
        sendCell.contentHeight.constant = [CommonUtil figrueStringHeight:((MessageObject*)[_contentAry objectAtIndex:indexPath.row]).text withSize:CGSizeMake(200, 100)];
        return sendCell;
    }else{
        ReceiveTableViewCell *receiveCell = [tableView dequeueReusableCellWithIdentifier:@"receiveCell"];
        return receiveCell;
    }
    
    

}
@end
