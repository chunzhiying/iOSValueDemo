//
//  BaseTableViewCell.m
//  IMDemo
//
//  Created by chenzy on 15/4/24.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "BaseTableViewCell.h"

@implementation BaseTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(float)figureTextHeight:(NSString*)str withSize:(CGSize)size{
    if (str) {
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        CGSize contentSize = [label.text boundingRectWithSize:CGSizeMake(label.bounds.size.width, 10000) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:15]} context:nil].size;
        return contentSize.height;
    }
    return 0;
    
}

@end
