//
//  AppModel.h
//  IMDemo
//
//  Created by chenzy on 15/4/24.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppModel : NSObject

@end
