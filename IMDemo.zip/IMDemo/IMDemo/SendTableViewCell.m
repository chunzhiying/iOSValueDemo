//
//  SendTableViewCell.m
//  IMDemo
//
//  Created by chenzy on 15/4/24.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "SendTableViewCell.h"

@implementation SendTableViewCell

- (void)awakeFromNib {
    self.portrait.layer.cornerRadius = CGRectGetHeight(self.portrait.bounds)/2;
    self.portrait.layer.masksToBounds = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}



@end
