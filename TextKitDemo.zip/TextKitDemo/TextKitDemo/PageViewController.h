//
//  iBookViewController.h
//  TextKitDemo
//
//  Created by chenzy on 15/5/12.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PageViewController : UIViewController<UIPageViewControllerDataSource,UIPageViewControllerDelegate>{
    UIPageViewController *_pageViewController;
}

@end
