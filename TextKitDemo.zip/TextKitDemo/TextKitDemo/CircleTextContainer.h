//
//  CircleTextContainer.h
//  TextKitDemo
//
//  Created by chenzy on 15/5/11.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CircleTextContainer : NSTextContainer

@end
