//
//  iBooksViewController.m
//  TextKitDemo
//
//  Created by chenzy on 15/5/12.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "iBooksViewController.h"


@interface iBooksViewController ()<NSLayoutManagerDelegate>{
    NSMutableArray *_textViewArys;
    NSInteger _currentPage;
    NSLayoutManager* _layoutManager;
    BOOL _isFinishReading;
}

@end

@implementation iBooksViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadBook];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Private
-(void)loadBook{
    NSTextStorage* storage = [NSTextStorage new];
    [storage replaceCharactersInRange:NSMakeRange(0, 0) withString:[NSString stringWithContentsOfURL:[[NSBundle mainBundle] URLForResource:@"iText" withExtension:@"txt"] encoding:NSUTF8StringEncoding error:nil]];
    
    [storage setAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:12]} range:NSMakeRange(0, storage.length)];
    
    _layoutManager = [NSLayoutManager new];
    _layoutManager.delegate = self;
    [storage addLayoutManager:_layoutManager];
    
    _textViewArys = [NSMutableArray new];
    _currentPage = 0;

    [self addTextView]; //添加首页
    
}

-(void)addTextView{
    
    NSTextContainer *container = [NSTextContainer new];
    [container setSize:CGSizeMake( CGRectGetWidth([UIScreen mainScreen].bounds), CGRectGetHeight([UIScreen mainScreen].bounds))];
    [_layoutManager addTextContainer:container];
    
    UITextView* textView = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth([UIScreen mainScreen].bounds), CGRectGetHeight([UIScreen mainScreen].bounds)) textContainer:container];
    textView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    textView.scrollEnabled = NO;
    [_textViewArys addObject:textView];
    
    UISwipeGestureRecognizer* swipeLeft =[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeLeft)];
    swipeLeft.direction = UISwipeGestureRecognizerDirectionLeft;
    [textView addGestureRecognizer:swipeLeft];
    
    UISwipeGestureRecognizer* swiftRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(swipeRight)];
    swiftRight.direction = UISwipeGestureRecognizerDirectionRight;
    [textView addGestureRecognizer:swiftRight];
    
    [self.view addSubview:textView];
    [self.view sendSubviewToBack:textView]; //把新增的textView放到视图最后
}

-(void)removeTextView{
    [_layoutManager removeTextContainerAtIndex:_layoutManager.textContainers.count-1];
    [[_textViewArys lastObject] removeFromSuperview];
    [_textViewArys removeLastObject];
}


#pragma mark - Gesture
-(void)swipeLeft{ //Next
    
    if (_isFinishReading) {
        [[[UIAlertView alloc] initWithTitle:@"提示" message:@"读完啦！== " delegate:self cancelButtonTitle:@"oh no!!" otherButtonTitles:
          nil] show];

        return;
    }
    
    [self addTextView];
    
    CATransition *transition = [CATransition animation];
    transition.duration = 1.0f;
    transition.type = @"pageCurl";
    transition.subtype = kCATransitionFromRight;
    UIView *view = [_textViewArys objectAtIndex:_currentPage];
    view.alpha = 0;
    _currentPage++;
    [view.layer addAnimation:transition forKey:nil];

}

-(void)swipeRight{ //last
    _isFinishReading = NO;
    if (_currentPage == 0) {
        [[[UIAlertView alloc] initWithTitle:@"提示" message:@"前面没字了！== " delegate:self cancelButtonTitle:@"oh no!!" otherButtonTitles:
          nil] show];
        return;
    }
    CATransition *transition = [CATransition animation];
    transition.type = @"pageUnCurl";
    transition.subtype = kCATransitionFromRight;
    transition.duration = 1;
    transition.delegate = self;
    [transition setValue:@"swipeRight" forKey:@"AnimationType"];
    _currentPage--;
    UIView *view = [_textViewArys objectAtIndex:_currentPage];
    view.alpha = 1;
    [view.layer addAnimation:transition forKey:nil];
    
}

#pragma mark - Animation Delegate
- (void)animationDidStop:(CAAnimation *)theAnimation finished:(BOOL)flag{
    if ([[theAnimation valueForKey:@"AnimationType"] isEqualToString:@"swipeRight"]) {
        [self removeTextView];
    }
}

#pragma mark - NSLayoutManager Delegate
- (void)layoutManager:(NSLayoutManager *)layoutManager didCompleteLayoutForTextContainer:(NSTextContainer *)textContainer atEnd:(BOOL)layoutFinishedFlag{
    
    if (textContainer == _layoutManager.textContainers.lastObject) {
        _isFinishReading = layoutFinishedFlag;
    }
  
}
@end
