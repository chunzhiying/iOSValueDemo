//
//  iBookViewController.m
//  TextKitDemo
//
//  Created by chenzy on 15/5/12.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "PageViewController.h"

@interface PageViewController (){
    NSArray *_viewControllers;
    NSInteger _currentPage;
}

@end

@implementation PageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _pageViewController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStylePageCurl navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil];
    _pageViewController.delegate = self;
    _pageViewController.dataSource = self;
    
    _viewControllers = @[[[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"VC1"],
                          [[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"VC2"],
                          [[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"VC3"]];
    
    [_pageViewController setViewControllers:@[[_viewControllers objectAtIndex:0]] direction:UIPageViewControllerNavigationDirectionForward animated:YES completion:nil];
    
    [self addChildViewController:_pageViewController];
    [self.view addSubview:_pageViewController.view];
    _currentPage = 0;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - PageViewController DataSource
- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController{
    _pageViewController.view.userInteractionEnabled = NO;
    _currentPage = _currentPage>0?_currentPage:_viewControllers.count;
    return [_viewControllers objectAtIndex:--_currentPage];
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController{
    _pageViewController.view.userInteractionEnabled = NO;
    _currentPage = _currentPage<_viewControllers.count-1?_currentPage:-1;
    
    NSLog(@"%@",[_viewControllers objectAtIndex:++_currentPage]);
    return [_viewControllers objectAtIndex:_currentPage];
}

#pragma mark - PageViewController Delegate
- (UIPageViewControllerSpineLocation)pageViewController:(UIPageViewController *)pageViewController spineLocationForInterfaceOrientation:(UIInterfaceOrientation)orientation{
    
    
    _pageViewController.doubleSided = NO;
    if (orientation == UIDeviceOrientationLandscapeRight || orientation == UIDeviceOrientationLandscapeLeft) {
        
        [_pageViewController setViewControllers:@[[[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"VC1"],
                                                  [[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"VC2"]]
                                      direction:UIPageViewControllerNavigationDirectionForward
                                       animated:YES
                                     completion:nil];
        
        return UIPageViewControllerSpineLocationMid;
    }else{
        [_pageViewController setViewControllers:@[[[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"VC1"]]
                                      direction:UIPageViewControllerNavigationDirectionForward
                                       animated:YES
                                     completion:nil];
        
        return UIPageViewControllerSpineLocationMin;
    }
}

- (void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray *)previousViewControllers transitionCompleted:(BOOL)completed{
    if (finished) {
        _pageViewController.view.userInteractionEnabled = YES;
    }
}

@end
