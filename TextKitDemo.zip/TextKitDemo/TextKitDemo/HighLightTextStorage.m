//
//  HighLightTextStorage.m
//  TextKitDemo
//
//  Created by chenzy on 15/5/8.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "HighLightTextStorage.h"

@implementation HighLightTextStorage{
    NSMutableAttributedString *_backingStore;
}


-(instancetype)init{
    self = [super init];
    if (self) {
        _backingStore  = [NSMutableAttributedString new];
    }
    return self;
}
#pragma mark - High lighting
-(void)processEditing{
    
    static NSRegularExpression *expression;
    expression = expression ?:[NSRegularExpression regularExpressionWithPattern:@"ip" options:0 error:NULL];
    
    NSLog(@"%@",NSStringFromRange(self.editedRange));
    
    //先移除
    NSRange paragraphRange = [self.string paragraphRangeForRange:self.editedRange];
    [self removeAttribute:NSForegroundColorAttributeName range:paragraphRange];
    //后添加
    [expression enumerateMatchesInString:self.string options:0 range:paragraphRange usingBlock:^(NSTextCheckingResult *result, NSMatchingFlags flags, BOOL *stop){
        [self addAttribute:NSForegroundColorAttributeName value:[UIColor yellowColor] range:result.range];
    }];
    [super processEditing];
}


#pragma mark - Reading Text
//1
-(NSString *)string{
    return _backingStore.string;
}

//2
-(NSDictionary*)attributesAtIndex:(NSUInteger)location effectiveRange:(NSRangePointer)range{
    return [_backingStore attributesAtIndex:location effectiveRange:range];
}

#pragma mark - Text Editing
//3
-(void)replaceCharactersInRange:(NSRange)range withString:(NSString *)str{
    NSLog(@"replaceCharactersInRange:%@ withString:%@",NSStringFromRange(range), str);
    [self beginEditing];
    [_backingStore replaceCharactersInRange:range withString:str];
    [self edited:NSTextStorageEditedCharacters | NSTextStorageEditedAttributes range:range changeInLength:str.length - range.length];
    [self endEditing];
}

//4
- (void)setAttributes:(NSDictionary *)attrs range:(NSRange)range {
    NSLog(@"setAttributes:%@ range:%@", attrs, NSStringFromRange(range));
    [self beginEditing];
    [_backingStore setAttributes:attrs range:range];
    [self edited:NSTextStorageEditedAttributes range:range changeInLength:0];
    [self endEditing];
}
@end
