//
//  ViewController.m
//  TextKitDemo
//
//  Created by chenzy on 15/5/8.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "TextKitViewController.h"
#import "HighLightTextStorage.h"
#import "CircleTextContainer.h"

@interface TextKitViewController ()<UITextViewDelegate>{
    
    __weak IBOutlet UITextView *_textView;
    __weak IBOutlet UIView *_leftSubView;
    __weak IBOutlet UIView *_rightSubView;
    
    HighLightTextStorage* _highLightStorage;
}

@end

@implementation TextKitViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initTextView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)unwindPageSegue:(UIStoryboardSegue*)segue{
}
-(IBAction)unwindBookSegue:(UIStoryboardSegue*)segue{
}

#pragma mark - Private
-(void)initTextView{
    
    NSMutableAttributedString * mainAttStr = [[NSMutableAttributedString alloc] initWithString:@"今天是个好日子！！"];
    
    NSTextAttachment *attachment = [[NSTextAttachment alloc] init];
    attachment.image = [UIImage imageNamed:@"a"];
    attachment.bounds = CGRectMake(0, 0, 20, 20);
    NSAttributedString* str = [NSAttributedString attributedStringWithAttachment:attachment];
    
    [mainAttStr insertAttributedString:str atIndex:mainAttStr.length-1];
    
//    _textView.attributedText = mainAttStr;

    
/*** 高亮 ***/
    _highLightStorage = [HighLightTextStorage new];
    [_highLightStorage addLayoutManager:_textView.layoutManager];
    [_highLightStorage replaceCharactersInRange:NSMakeRange(0, 0) withString:[NSString stringWithContentsOfURL:[[NSBundle mainBundle] URLForResource:@"lorem" withExtension:@"txt"] encoding:NULL  error:NULL]];
    [_highLightStorage insertAttributedString:mainAttStr atIndex:_highLightStorage.length];
    
    //路径排除
    _textView.textContainer.exclusionPaths = @[[UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 100, 100, 100)],[UIBezierPath bezierPathWithRect:CGRectMake(150, 100, 100, 100)]];
   
/*** 多容器布局 ***/
    NSLayoutManager *otherManager = [NSLayoutManager new];
    [_highLightStorage addLayoutManager:otherManager];
    
    //left
    NSTextContainer *otherContainer = [NSTextContainer new];
    [otherManager addTextContainer:otherContainer];
    
    UITextView *otherTextView = [[UITextView alloc] initWithFrame:_leftSubView.bounds textContainer:otherContainer];
    otherTextView.tag = 999;
    otherTextView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    otherTextView.scrollEnabled = NO;
    [_leftSubView addSubview:otherTextView];

    //right
    NSTextContainer *thirdContainer = [NSTextContainer new];
    [otherManager addTextContainer:thirdContainer];
    
    UITextView *thirdTextView = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, otherTextView.bounds.size.width, [UIScreen mainScreen].bounds.size.height/2) textContainer:thirdContainer];
    thirdTextView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [_rightSubView addSubview:thirdTextView];
    

    _textView.allowsEditingTextAttributes = YES;
    _textView.editable = NO;
    
    //手势
    UISwipeGestureRecognizer* gesture = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(gesture)];
    gesture.direction = UISwipeGestureRecognizerDirectionUp;
    [otherTextView addGestureRecognizer:gesture];
    
    ///*** 圆形容器 ***/
    
    NSLayoutManager *circleLayoutManager = [NSLayoutManager new];
    CircleTextContainer *circleContainer = [[CircleTextContainer alloc] initWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width)];
//    CircleTextContainer *circleContainer1 = [[CircleTextContainer alloc] initWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width)];

    NSMutableParagraphStyle* style = [NSMutableParagraphStyle new];
    [style setAlignment:NSTextAlignmentJustified];
    [_highLightStorage addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0,_highLightStorage.length)];
    [_highLightStorage addLayoutManager:circleLayoutManager]; //获得一份完整的storage内容
    
    //分成多少个容器来展示
    [circleLayoutManager addTextContainer:circleContainer];
//    [circleLayoutManager addTextContainer:circleContainer1];
    
    UITextView *circleTextView = [[UITextView alloc] initWithFrame:CGRectMake(0, 20, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width) textContainer:circleContainer];
    circleTextView.backgroundColor = [UIColor yellowColor];
    
//    UITextView *circleTextView1 = [[UITextView alloc] initWithFrame:CGRectMake(0, 20+[UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.width) textContainer:circleContainer1];
//    circleTextView1.backgroundColor = [UIColor blueColor];

//    [self.view addSubview:circleTextView];
//    [self.view addSubview:circleTextView1];
}

-(void)gesture{
    CATransition *transition = [CATransition animation];
    transition.type = @"pageCurl";
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    UIView *view = [self.view viewWithTag:999];
    transition.duration = 3;
    view.alpha = 0;
    [view.layer addAnimation:transition forKey:nil];
}


#pragma mark - TextView Delegate
- (BOOL)textView:(UITextView *)textView shouldInteractWithTextAttachment:(NSTextAttachment *)textAttachment inRange:(NSRange)characterRange{
    return YES;
}
@end
