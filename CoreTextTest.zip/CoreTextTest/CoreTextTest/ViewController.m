//
//  ViewController.m
//  CoreTextTest
//
//  Created by 陈智颖 on 15/3/23.
//  Copyright (c) 2015年 陈智颖. All rights reserved.
//

#import "ViewController.h"
#import "CTView.h"
#import "DyView.h"

@interface ViewController (){
    CTView *_ctView;
    DyView *_dyView;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _dyView = [[DyView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height/2)];
    _dyView.backgroundColor = [UIColor whiteColor];
    
    _ctView = [[CTView alloc] initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height/2, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height/2)];
    _ctView.backgroundColor = [UIColor grayColor];
    
   
    
    [self.view addSubview:_ctView];
    [self.view addSubview:_dyView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
