//
//  DyView.m
//  CoreTextTest
//
//  Created by 陈智颖 on 15/3/24.
//  Copyright (c) 2015年 陈智颖. All rights reserved.
//

#import "DyView.h"
#import <CoreText/CoreText.h>

@interface DyView(){
    UITextView* _txtView;
    NSMutableAttributedString *_attString;
    NSInteger _strLength; //文字个数
    NSMutableArray* _imgPosAry; //存储图片位置
    int _imgNum; //图片个数
}
@end

@implementation DyView

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {

    _attString = [[NSMutableAttributedString alloc] init];
    _strLength = 0;_imgNum = 0;
    _imgPosAry = [NSMutableArray new];
    
    _txtView = [[UITextView alloc]initWithFrame:CGRectMake(0, 20, self.frame.size.width, self.frame.size.height-20)];
    _txtView.backgroundColor = [UIColor whiteColor];
    _txtView.delegate = self;
    [self addSubview:_txtView];
    
    UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width-80, 0, 80, 50)];
    [btn setTitle:@"加图片" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor]forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    btn.backgroundColor = [UIColor yellowColor];
    [self addSubview:btn];
}

// 添加图片
-(void)btnClick{

    NSTextAttachment *emojiTextAttachment = [NSTextAttachment new];
    emojiTextAttachment.image = [UIImage imageNamed:@"YYLogo"];
    [_attString insertAttributedString:[NSAttributedString attributedStringWithAttachment:emojiTextAttachment]atIndex:[_attString length]];
    _txtView.attributedText = _attString;
    _imgNum++;
    NSString* num = [[NSString alloc]initWithFormat:@"%d",_txtView.text.length];    [_imgPosAry addObject:num];
}



#pragma mark - UITextViewDelegate
- (void)textViewDidChange:(UITextView *)textView{

    if ([[_imgPosAry lastObject] integerValue] == textView.text.length+1) { //减图片数目
        _imgNum--;
        [_imgPosAry removeLastObject];
    }

    if (textView.text.length-_imgNum>_strLength) { //加
        NSAttributedString* str = [[NSAttributedString alloc] initWithString:[textView.text substringFromIndex:_strLength+_imgNum]];
        [_attString insertAttributedString:str atIndex:_attString.length];
        _strLength = textView.text.length-_imgNum;
    }
    else if(textView.text.length-_imgNum<=_strLength){ //减
        [_attString deleteCharactersInRange:NSMakeRange(textView.text.length,1)];
        _strLength = textView.text.length-_imgNum;
    }
    
    NSLog(@"img:%d,text:%d,strLeng:%d",_imgNum,textView.text.length,_strLength);

    // 初始化
    [_attString addAttribute:(NSString *)kCTFontAttributeName value:[UIFont systemFontOfSize:24] range:NSMakeRange(0, [_attString length])];
    [_attString addAttribute:kCTUnderlineStyleAttributeName value:[NSNumber numberWithInt:kCTUnderlineStyleDouble] range:NSMakeRange(0, [_attString length])];

    _txtView.attributedText = _attString;
}

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
        return NO;
    }
    return YES;
}

@end
