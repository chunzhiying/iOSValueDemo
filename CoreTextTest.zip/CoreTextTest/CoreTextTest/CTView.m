//
//  CTView.m
//  CoreTextTest
//
//  Created by 陈智颖 on 15/3/23.
//  Copyright (c) 2015年 陈智颖. All rights reserved.
//

#import "CTView.h"
#import <CoreText/CoreText.h>

@interface CTView(){
    NSMutableArray *_runAry;
    CTFrameRef _ctFrame;
}

@end

@implementation CTView

void RunDelegateDeallocCallback( void* refCon ){
    
}

CGFloat RunDelegateGetAscentCallback( void *refCon ){
    NSString *imageName = (__bridge NSString *)refCon;
    return [UIImage imageNamed:imageName].size.height;
}

CGFloat RunDelegateGetDescentCallback(void *refCon){
    return 0;
}

CGFloat RunDelegateGetWidthCallback(void *refCon){
    NSString *imageName = (__bridge NSString *)refCon;
    return [UIImage imageNamed:imageName].size.width;
}


- (void)drawRect:(CGRect)rect {
    
    _runAry = [NSMutableArray new];
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // CT的坐标原点在左下角，反转坐标系
    CGAffineTransform flipVertical = CGAffineTransformMake(1,0,0,-1,0,self.bounds.size.height);
    CGContextConcatCTM(context, flipVertical);
    
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:@"今天是个好日子"] ;
    //设置字体大小
    [attributedString addAttribute:(NSString *)kCTFontAttributeName value:[UIFont systemFontOfSize:24] range:NSMakeRange(0, [attributedString length])];
    //将“今天”两字字体颜色设置为蓝色、下划线
    [attributedString addAttribute:kCTUnderlineStyleAttributeName value:[NSNumber numberWithInt:kCTUnderlineStyleDouble] range:NSMakeRange(0, 2)];
    [attributedString addAttribute:(NSString *)kCTForegroundColorAttributeName value:(id)[UIColor blueColor].CGColor range:NSMakeRange(0, 2)];
    
    
    //为图片设置CTRunDelegate,delegate决定留给图片的空间大小
    NSString *YYImageName = @"YYLogo.png";
    CTRunDelegateCallbacks imageCallbacks;
    imageCallbacks.version = kCTRunDelegateVersion1;
    imageCallbacks.dealloc = RunDelegateDeallocCallback;
    imageCallbacks.getAscent = RunDelegateGetAscentCallback;
    imageCallbacks.getDescent = RunDelegateGetDescentCallback;
    imageCallbacks.getWidth = RunDelegateGetWidthCallback;
    CTRunDelegateRef runDelegate = CTRunDelegateCreate(&imageCallbacks, (__bridge void *)(YYImageName));
    
    NSMutableAttributedString *imageAttributedString = [[NSMutableAttributedString alloc] initWithString:@" "];//空格用于给图片留位置
    [imageAttributedString addAttribute:(NSString *)kCTRunDelegateAttributeName value:(__bridge id)runDelegate range:NSMakeRange(0, 1)];
    CFRelease(runDelegate);
    //给图片设置专用的CTRun
    [imageAttributedString addAttribute:@"imageName" value:YYImageName range:NSMakeRange(0, 1)];
    
    //把图片的空格插入文本中
    [attributedString insertAttributedString:imageAttributedString atIndex:3];
    
    //把文本内容显示出来
    CTFramesetterRef ctFramesetter = CTFramesetterCreateWithAttributedString((CFMutableAttributedStringRef)attributedString);
    CGMutablePathRef path = CGPathCreateMutable();
    CGPathAddRect(path, NULL, CGRectMake(0.0, 0.0, self.bounds.size.width, self.bounds.size.height));
    _ctFrame = CTFramesetterCreateFrame(ctFramesetter,CFRangeMake(0, 0), path, NULL);
    CTFrameDraw(_ctFrame, context);
    
    CFArrayRef lines = CTFrameGetLines(_ctFrame);
    CGPoint lineOrigins[CFArrayGetCount(lines)];
    CTFrameGetLineOrigins(_ctFrame, CFRangeMake(0, 0), lineOrigins);
    
    //获取每一行
    for (int i = 0; i < CFArrayGetCount(lines); i++) {
        CTLineRef line = CFArrayGetValueAtIndex(lines, i);
        CGFloat lineAscent;
        CGFloat lineDescent;
        CGFloat lineLeading;
        CTLineGetTypographicBounds(line, &lineAscent, &lineDescent, &lineLeading); //每行宽高
        
        // 获取每一个CTRun
        CFArrayRef runs = CTLineGetGlyphRuns(line);
        for (int j = 0; j < CFArrayGetCount(runs); j++) {
            CGFloat runAscent;
            CGFloat runDescent;
            CGPoint lineOrigin = lineOrigins[i];
            CTRunRef run = CFArrayGetValueAtIndex(runs, j); //每一个Run
            NSDictionary* attributes = (NSDictionary*)CTRunGetAttributes(run);
            CGRect runRect;
            CGPathRef path = CTFrameGetPath(_ctFrame);
            
            //获取整个CTFrame的大小
            CGRect rect = CGPathGetBoundingBox(path);
            NSStringFromCGPoint(lineOrigin);
            NSStringFromCGRect(rect);
            CGFloat y = rect.origin.y + rect.size.height - lineOrigin.y; //此时的y是这一行的底线的坐标
            
            runRect.size.width = CTRunGetTypographicBounds(run, CFRangeMake(0,0), &runAscent, &runDescent, NULL);
            runRect=CGRectMake(lineOrigin.x + CTLineGetOffsetForStringIndex(line, CTRunGetStringRange(run).location, NULL),y, runRect.size.width, runAscent + runDescent);
        
            // 获得每个CTRun的Rect
            NSLog(@"%f,%f,%f,%f",runRect.origin.x,y-runRect.size.height,runRect.size.width,runRect.size.height);
            [_runAry addObject:[NSValue valueWithCGRect:CGRectMake(runRect.origin.x,y-runRect.size.height,runRect.size.width,runRect.size.height)]];

            
            //找到需要被图片替换的字符位置
            NSString *imageName = [attributes objectForKey:@"imageName"];
            //用core graphic画上图片
            if (imageName) {
                UIImage *image = [UIImage imageNamed:imageName];
                if (image) {
                    CGRect imageDrawRect;
                    imageDrawRect.size = image.size;
                    imageDrawRect.origin.x = runRect.origin.x + lineOrigin.x;
                    imageDrawRect.origin.y = lineOrigin.y;
                    CGContextDrawImage(context, imageDrawRect, image.CGImage);
                }
            }
        }
    }
    
    CFRelease(_ctFrame);
    CFRelease(path);
    CFRelease(ctFramesetter);
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:self];

    NSLog(@"%f,%f",location.x,location.y);
    
    if((location.x - [[_runAry objectAtIndex:0] CGRectValue].origin.x ) < [[_runAry objectAtIndex:0] CGRectValue].size.width &&
       (location.y - [[_runAry objectAtIndex:0] CGRectValue].origin.y ) < [[_runAry objectAtIndex:0] CGRectValue].size.height &&
       (location.x - [[_runAry objectAtIndex:0] CGRectValue].origin.x ) > 0 &&
       (location.y - [[_runAry objectAtIndex:0] CGRectValue].origin.y ) > 0 ){
        [[[UIAlertView alloc] initWithTitle:nil message:@"good" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];
    }
}

@end
