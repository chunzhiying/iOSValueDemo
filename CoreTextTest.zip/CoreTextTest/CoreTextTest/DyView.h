//
//  DyView.h
//  CoreTextTest
//
//  Created by 陈智颖 on 15/3/24.
//  Copyright (c) 2015年 陈智颖. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DyView : UIView <UITextViewDelegate>

@end
