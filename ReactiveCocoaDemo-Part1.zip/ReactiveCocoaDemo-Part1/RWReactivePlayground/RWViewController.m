//
//  RWViewController.m
//  RWReactivePlayground
//
//  Created by Colin Eberhardt on 18/12/2013.
//  Copyright (c) 2013 Colin Eberhardt. All rights reserved.
//

#import "RWViewController.h"
#import "RWDummySignInService.h"
#import <ReactiveCocoa/ReactiveCocoa.h>

@interface RWViewController ()

@property (weak, nonatomic) IBOutlet UITextField *usernameTextField;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
@property (weak, nonatomic) IBOutlet UIButton *signInButton;
@property (weak, nonatomic) IBOutlet UILabel *signInFailureText;

@property (strong, nonatomic) RWDummySignInService *signInService;

@end

@implementation RWViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  
  self.signInService = [RWDummySignInService new];
  self.signInFailureText.hidden = YES;
    
    @weakify(self);
    // 信号的生成
    RACSignal *userNameSignal = [self.usernameTextField.rac_textSignal map:^id(NSString* value){
        return @([self isValidUsername:value]);
    }];
    
    RACSignal *passWordSignal = [self.passwordTextField.rac_textSignal map:^id(NSString* value){
        return @([self isValidPassword:value]);
    }];
    
    RACSignal *combineSignal = [RACSignal combineLatest:@[userNameSignal,passWordSignal]
                                                 reduce:^id(NSNumber *usernameValid, NSNumber *passwordValid){
                                                     return @([usernameValid boolValue] && [passwordValid boolValue]);
                                                 }];
    
    // 输入框的状态: RAC设置
    RAC(self.usernameTextField,backgroundColor) = [userNameSignal map:^id(NSNumber *x){
        return [x boolValue] ? [UIColor clearColor] : [UIColor yellowColor];
    }];
    
    RAC(self.passwordTextField,backgroundColor) = [passWordSignal map:^id(NSNumber* value){
        return [value boolValue] ? [UIColor clearColor] : [UIColor yellowColor];
    }];
    
    [combineSignal subscribeNext:^(NSNumber *value){
        self.signInButton.enabled = [value boolValue];
    }];
 
    [[[self.signInButton rac_signalForControlEvents:(UIControlEventTouchUpInside)] flattenMap:^id(id x){
        return [self signInSignal];
    }] subscribeNext:^(id x){
        @strongify(self);
        BOOL success = [x boolValue];
        self.signInFailureText.hidden = success;
        if(success){
            [self performSegueWithIdentifier:@"signInSuccess" sender:self];
        }
    }];
    
    // RACObserve：监听
    [RACObserve(self, usernameTextField.text) subscribeNext:^(id x){
        @strongify(self);
        NSLog(@"%@",self.usernameTextField.text);
    }];
}

- (BOOL)isValidUsername:(NSString *)username {
  return username.length > 3;
}

- (BOOL)isValidPassword:(NSString *)password {
  return password.length > 3;
}

- (RACSignal*)signInSignal{
    return [RACSignal createSignal:^RACDisposable *(id subscriber){
        [self.signInService signInWithUsername:self.usernameTextField.text
                                      password:self.passwordTextField.text
                                      complete:^(BOOL success) {
                                          [subscriber sendNext:@(success)];
                                          [subscriber sendCompleted];
                                      }];
        return nil;
    }];
}

@end
