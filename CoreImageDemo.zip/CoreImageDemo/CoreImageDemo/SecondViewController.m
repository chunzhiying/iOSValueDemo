//
//  SecondViewController.m
//  CoreImageDemo
//
//  Created by chenzy on 15/5/18.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "SecondViewController.h"
#import <CoreImage/CoreImage.h>

@interface SecondViewController (){
    
    __weak IBOutlet UIImageView *_meiziImage;
    __weak IBOutlet UISlider *_slider;
    CIContext *_myContext;
    CIFilter *_filter;
}

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initImage];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Private Method
-(void)initImage{
    _meiziImage.layer.shadowOffset = CGSizeMake(3, 4);
    _meiziImage.layer.shadowRadius = 10.0f;
    _meiziImage.layer.shadowOpacity = 0.8;
    
    _slider.minimumValue = -M_PI;
    _slider.maximumValue = M_PI;
    [_slider addTarget:self action:@selector(clickSlider:) forControlEvents:UIControlEventTouchDragInside];
    
    _myContext = [CIContext contextWithOptions:nil];
    
//    CIFilter *filter = [CIFilter filterWithName:@"CIStarShineGenerator"];
//    [filter setDefaults];
//    [filter setValue:[NSNumber numberWithFloat:30/2] forKey:@"inputRadius"];
//    [filter setValue:[NSNumber numberWithFloat:1] forKey:@"inputCrossWidth"];
//    [filter setValue:[NSNumber numberWithFloat:2] forKey:@"inputCrossScale"];
//    [filter setValue:[[CIColor alloc] initWithColor:[UIColor blueColor]] forKey:@"inputColor"];
//    [filter setValue:[CIVector vectorWithX:30 Y:30] forKey:@"inputCenter"];
//    image = filter.outputImage;
//    _meiziImage.image = [UIImage imageWithCGImage:[_myContext createCGImage:image fromRect:CGRectMake(0, 0, 60, 60)]];
    
}

-(void)clickSlider:(UISlider*)sender{
    CIImage *image = [CIImage imageWithCGImage:[UIImage imageNamed:@"meizi"].CGImage];
    _filter = [CIFilter filterWithName:@"CIHueAdjust"];
    [_filter setValue:image forKey:kCIInputImageKey];
    [_filter setValue:@(sender.value) forKey:kCIInputAngleKey];
    CIImage *outputImage = _filter.outputImage;
    _meiziImage.image = [UIImage imageWithCGImage:[_myContext createCGImage:outputImage fromRect:outputImage.extent]];
}

#pragma mark - IBAction
- (IBAction)showOldFilm:(id)sender {
//    //老电影滤镜
    CIFilter *oldFilmFilter = [CIFilter filterWithName:@"CISepiaTone"];
    CIImage* image = [CIImage imageWithCGImage:[UIImage imageNamed:@"meizi"].CGImage];
    [oldFilmFilter setValue:image forKey:kCIInputImageKey];
    [oldFilmFilter setValue:@(0.8) forKey:@"inputIntensity"];
    _meiziImage.image = [UIImage imageWithCGImage:[_myContext createCGImage:oldFilmFilter.outputImage fromRect:oldFilmFilter.outputImage.extent]];
    
    //模糊
    CIFilter *motionBlur = [CIFilter filterWithName:@"CIGaussianBlur"];
    [motionBlur setDefaults];
    [motionBlur setValue:image forKey:kCIInputImageKey];
    [motionBlur setValue:@(10.0f) forKey:kCIInputRadiusKey];
//    [motionBlur setValue:@(1.0f) forKey:kCIInputAngleKey];
//    _meiziImage.image = [UIImage imageWithCGImage:[_myContext createCGImage:motionBlur.outputImage fromRect:motionBlur.outputImage.extent]];
    _meiziImage.image = [UIImage imageWithCIImage:motionBlur.outputImage];
    
}
@end
