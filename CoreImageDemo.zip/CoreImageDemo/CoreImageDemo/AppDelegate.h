//
//  AppDelegate.h
//  CoreImageDemo
//
//  Created by chenzy on 15/5/18.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

