//
//  ViewController.m
//  CoreImageDemo
//
//  Created by chenzy on 15/5/18.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "FirstViewController.h"
#import <CoreImage/CoreImage.h>

@interface FirstViewController (){
    
    CIContext *_myContext;
    CIFilter *_filter;
    __weak IBOutlet UIImageView *_meiziImage;
    
}

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initImage];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Private Method
-(void)initImage{
    _myContext = [CIContext contextWithOptions:nil]; //基于GPU的context
    _meiziImage.layer.shadowOpacity = 0.8;
    _meiziImage.layer.shadowRadius = 10.0f;
    _meiziImage.layer.shadowOffset = CGSizeMake(3.0f, 4.0f);
}

-(void)onOutputImage{
    CIImage* tempImage = [CIImage imageWithCGImage:_meiziImage.image.CGImage];
    [_filter setValue:tempImage forKey:kCIInputImageKey];
    tempImage = _filter.outputImage;
    _meiziImage.image = [UIImage imageWithCGImage:[_myContext createCGImage:tempImage fromRect:tempImage.extent]];
}

#pragma mark - IBAction
- (IBAction)clickOriginalImage:(id)sender {
    _meiziImage.image = [UIImage imageNamed:@"meizi"];
}

//自动修图
- (IBAction)autoAdjustment:(id)sender {
    CIImage *tempImage = [CIImage imageWithCGImage:[UIImage imageNamed:@"meizi"].CGImage];
    for (CIFilter* filter in tempImage.autoAdjustmentFilters) {
        [filter setValue:tempImage forKey:kCIInputImageKey];
        tempImage = filter.outputImage;
    }
//    _meiziImage.image = [UIImage imageWithCIImage:tempImage];//每次调用都会创建一个新的CIContext
    _meiziImage.image = [UIImage imageWithCGImage:[_myContext createCGImage:tempImage fromRect:tempImage.extent]];
}

- (IBAction)showAllFilter:(id)sender {
    
}

#pragma mark - Filter
- (IBAction)huaijiu:(id)sender {
    _filter = [CIFilter filterWithName:@"CIPhotoEffectInstant"];
    [self onOutputImage];
}
- (IBAction)sediao:(id)sender {
    _filter = [CIFilter filterWithName:@"CIPhotoEffectNoir"];
    [self onOutputImage];
}
- (IBAction)suiyue:(id)sender {
    _filter = [CIFilter filterWithName:@"CIPhotoEffectTonal"];
    [self onOutputImage];
}
- (IBAction)heibai:(id)sender {
    _filter = [CIFilter filterWithName:@"CIPhotoEffectTransfer"];
    [self onOutputImage];
}
- (IBAction)tuise:(id)sender {
    _filter = [CIFilter filterWithName:@"CIPhotoEffectMono"];
    [self onOutputImage];
}
- (IBAction)chongyin:(id)sender {
    _filter = [CIFilter filterWithName:@"CIPhotoEffectFade"];
    [self onOutputImage];
}
- (IBAction)gehuang:(id)sender {
    _filter = [CIFilter filterWithName:@"CIPhotoEffectProcess"];
    [self onOutputImage];
}
- (IBAction)danse:(id)sender {
    _filter = [CIFilter filterWithName:@"CIPhotoEffectChrome"];
    [self onOutputImage];
}

@end
