//
//  ThirdViewController.m
//  CoreImageDemo
//
//  Created by chenzy on 15/5/20.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "ThirdViewController.h"

@interface ThirdViewController (){
    
    __weak IBOutlet UIImageView *_faceImage;
    CIContext *_myContext;
}

@end

@implementation ThirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _myContext = [CIContext contextWithOptions:nil];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - IBAction
- (IBAction)faceIndentify:(id)sender {
    CIImage* image = [CIImage imageWithCGImage:[UIImage imageNamed:@"face"].CGImage];
    CIDetector* detecor = [CIDetector detectorOfType:CIDetectorTypeFace //检测的内容 （人脸、二维码等）
                                             context:_myContext
                                             options:@{CIDetectorAccuracy:CIDetectorAccuracyHigh}];
    
    NSArray* faceArys = [detecor featuresInImage:image]; //得到人脸的数组
    
    
    CGAffineTransform transform = CGAffineTransformTranslate(CGAffineTransformScale(CGAffineTransformIdentity,1,-1),0,-image.extent.size.height); //反转
    
    for (CIFaceFeature* faceFeature in faceArys) {
        
        CGRect faceBounds = CGRectApplyAffineTransform(CGRectApplyAffineTransform(faceFeature.bounds,transform),CGAffineTransformMakeScale(0.5,0.5));//应用反转transform，并且缩小为一半
        
        UIView *face = [[UIView alloc] initWithFrame:faceBounds];
        face.layer.borderColor = [UIColor blueColor].CGColor;
        face.layer.borderWidth = 2.0f;
        
        [_faceImage addSubview:face];
        
        
        
//        CIFilter *pixellate = [CIFilter filterWithName:@"CIPixellate"];
//        [pixellate setDefaults];
//        [pixellate setValue:image forKey:kCIInputImageKey];
//        [pixellate setValue:[[CIVector alloc] initWithCGPoint:CGPointMake(faceBounds.origin.x+faceBounds.size.width/2, faceBounds.origin.y+faceBounds.size.height/2)] forKey:kCIInputCenterKey];
//        [pixellate setValue:@(10) forKey:kCIInputScaleKey];
//        _faceImage.image = [UIImage imageWithCGImage:[_myContext createCGImage:pixellate.outputImage fromRect:pixellate.outputImage.extent]];
    }
    
//    CALayer *layer = [CALayer layer];
//    layer.backgroundColor = [UIColor yellowColor].CGColor;
    
    CIFilter *blurFilter = [CIFilter filterWithName:@"CIGaussianBlur"];
    NSLog(@"%@",blurFilter.attributes) ;
    [blurFilter setDefaults];
//    [blurFilter setValue:image forKey:kCIInputImageKey];
    [blurFilter setValue:@(10) forKey:kCIInputRadiusKey];
//    _faceImage.image = [UIImage imageWithCGImage:[_myContext createCGImage:blurFilter.outputImage fromRect:blurFilter.outputImage.extent]];
    [_faceImage.layer setFilters:@[blurFilter]];
    
//    [_faceImage.layer addSublayer:layer];
    
    
}

@end
