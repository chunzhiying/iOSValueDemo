//
//  ViewController.m
//  CoreAnimationLayerDemo
//
//  Created by chenzy on 15/5/4.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "FirstVC.h"
#import <QuartzCore/QuartzCore.h>

#define SCREENWIDTH [UIScreen mainScreen].bounds.size.width
#define SCREENHEIGHT [UIScreen mainScreen].bounds.size.height

@interface FirstVC (){
    NSArray *_nameAry;
    CALayer* itemLayer;
    CAShapeLayer *_strokeShapeLayer;
    
    NSArray* _safariAry;
}

@end

@implementation FirstVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _nameAry = @[@"a",@"b",@"c",@"d"];
    
    [self initLayer];
    [self initShapeLayer];
    [self initTrasition];
    [self initSfariLayer];
    [self initClockLayer];
    [self initGradientLayer];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


#pragma mark - ShapeLayer
-(void)initShapeLayer{
    
    _strokeShapeLayer = [CAShapeLayer layer];
    _strokeShapeLayer.frame = CGRectMake(0, 0, 100, 100);
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, 100, 100) cornerRadius:50];
    _strokeShapeLayer.path = path.CGPath;
    _strokeShapeLayer.strokeColor = [[UIColor grayColor] CGColor];
    _strokeShapeLayer.fillColor = [[UIColor clearColor] CGColor];
    _strokeShapeLayer.lineWidth = 3.0;
    [self.view.layer addSublayer:_strokeShapeLayer];
    
    CABasicAnimation *startAni = [CABasicAnimation animationWithKeyPath:@"strokeStart"];
    startAni.fromValue = @(0);
    startAni.toValue = @(0.25);
    startAni.duration = 1;
    
    CABasicAnimation* startAniEnd = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    startAniEnd.fromValue = @(0);
    startAniEnd.toValue = @(1);
    startAniEnd.duration = 1;
    
    CABasicAnimation* endAni = [CABasicAnimation animationWithKeyPath:@"strokeStart"];
    endAni.beginTime = 1;
    endAni.fromValue = @(0.25);
    endAni.toValue = @(1);
    endAni.duration = 0.5;
    
    CABasicAnimation* endAniEnd = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    endAniEnd.beginTime = 1;
    endAniEnd.fromValue = @(1);
    endAniEnd.toValue = @(1);
    endAniEnd.duration = 0.5;
    
    CAAnimationGroup* groupAnimation = [CAAnimationGroup animation];
    groupAnimation.animations = @[startAni,startAniEnd,endAni,endAniEnd];
    [groupAnimation setValue:@"YES" forKey:@"isGroupAnimation"];
    groupAnimation.delegate = self;
    groupAnimation.duration = 1.5;
    groupAnimation.repeatCount = INFINITY;
    
    [_strokeShapeLayer addAnimation:groupAnimation forKey:@"strokeGroup"];
    
    CABasicAnimation *rotationAni = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
    rotationAni.fromValue = @(0);
    rotationAni.toValue = @(M_PI*2);
    _strokeShapeLayer.anchorPoint = CGPointMake(0.5, 0.5);
    rotationAni.duration = 4;
    rotationAni.repeatCount = INFINITY;
    rotationAni.cumulative = YES;
    [_strokeShapeLayer addAnimation:rotationAni forKey:nil];
    
}

#pragma mark - Basic
-(void)initLayer{
    self.view.layer.backgroundColor = [[UIColor whiteColor] CGColor];
    
    itemLayer = [CALayer layer];
    itemLayer.backgroundColor = [[UIColor greenColor] CGColor];
    itemLayer.frame = CGRectMake((SCREENWIDTH-100)/2, (SCREENWIDTH-100)/2, 100, 100);
    
    CIFilter *filter = [CIFilter filterWithName:@"CIBloom"];
    [filter setDefaults];
    [filter setValue:[NSNumber numberWithFloat:5.0f] forKey:@"inputRadius"];
    [itemLayer setFilters:@[filter]];
    
    itemLayer.anchorPoint = CGPointMake(0.5, 0.5);
    
    [self.view.layer addSublayer:itemLayer];
    
    CABasicAnimation *scaleAni = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    scaleAni.fromValue = [NSValue valueWithCATransform3D:CATransform3DIdentity];
    scaleAni.toValue = [NSValue valueWithCATransform3D:CATransform3DMakeScale(0.1, 0.1, 1.0)];
    scaleAni.autoreverses = YES;
    scaleAni.duration = 1.0;
    
    CAKeyframeAnimation *pathAni = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:itemLayer.position];
    [path addLineToPoint:CGPointMake(SCREENWIDTH, 0)];
    pathAni.duration = 1;
    pathAni.path = path.CGPath;
    
    CABasicAnimation *ani = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
    ani.fromValue =[NSValue valueWithCATransform3D:CATransform3DIdentity];
    ani.toValue = [NSValue valueWithCATransform3D: CATransform3DMakeRotation(M_PI,0,0,1)];
    ani.cumulative = NO;
    ani.duration =0.1;
    ani.repeatCount =10;
    
    CAAnimationGroup* animationGroup = [CAAnimationGroup animation];
    animationGroup.animations = @[pathAni,scaleAni,ani];
    animationGroup.duration = 1.0;
    animationGroup.repeatCount = INFINITY;
    animationGroup.autoreverses = YES;
    animationGroup.removedOnCompletion = NO;
    
    [itemLayer addAnimation:animationGroup forKey:nil];
    
}


#pragma mark - CATrasition
-(void)initTrasition{
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(0, SCREENHEIGHT/2)];
    [path addCurveToPoint:CGPointMake(SCREENWIDTH, SCREENHEIGHT/2) controlPoint1:CGPointMake(SCREENWIDTH/3, SCREENHEIGHT/4) controlPoint2:CGPointMake(SCREENWIDTH*2/3, SCREENHEIGHT*2/3)];
    
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.path = path.CGPath;
    shapeLayer.fillColor = [UIColor clearColor].CGColor;
    shapeLayer.strokeColor = [UIColor grayColor].CGColor;
    shapeLayer.lineWidth = 3.0;
    [self.view.layer addSublayer:shapeLayer];
    
    CALayer* imageLayer = [CALayer layer];
    imageLayer.contents = (__bridge id)([UIImage imageNamed:@"a"].CGImage);
    imageLayer.frame = CGRectMake(0, SCREENHEIGHT/2, 37, 37);
    [self.view.layer addSublayer:imageLayer];
    
    CAKeyframeAnimation *imageAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    imageAnimation.path = path.CGPath;
    imageAnimation.duration = 5.0;
    imageAnimation.repeatCount = INFINITY;
    imageAnimation.autoreverses = YES;
    imageAnimation.rotationMode = kCAAnimationRotateAuto;
    imageAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    [imageLayer addAnimation:imageAnimation forKey:nil];
    
    [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(changeImage:) userInfo:@{@"layer":imageLayer} repeats:YES];
}

-(void)changeImage:(NSTimer*)timer{
    CALayer* layer = timer.userInfo[@"layer"];
    static NSInteger num=1;
    CATransition *transition = [CATransition animation];
    transition.type = kCATransitionFade;
    [layer addAnimation:transition forKey:nil];
    
    num = num > 3 ? 0 : num;
    layer.contents = (__bridge id)([UIImage imageNamed:[_nameAry objectAtIndex:num++]].CGImage);
}

#pragma mark - Safari Animation

-(void)initSfariLayer{
    CALayer* firstLayer = [CALayer layer];
    firstLayer.frame = CGRectMake((SCREENWIDTH-100)*4/5, (SCREENHEIGHT-100)*7/9, 100, 100);
    firstLayer.contents = (__bridge id)([UIImage imageNamed:[_nameAry objectAtIndex:3]].CGImage);
    [self.view.layer addSublayer:firstLayer];
    
    CALayer* secondLayer = [CALayer layer];
    secondLayer.frame = CGRectMake((SCREENWIDTH-100)*4/5, (SCREENHEIGHT-100)*11/12, 100, 100);
    secondLayer.contents = (__bridge id)([UIImage imageNamed:[_nameAry objectAtIndex:0]].CGImage);
    [self.view.layer addSublayer:secondLayer];
    
    firstLayer.shadowColor = [UIColor greenColor].CGColor;
    firstLayer.shadowRadius = 10;
    firstLayer.shadowOffset = CGSizeMake(0.0f, 5.0f);
    firstLayer.shadowOpacity = 0.8;

    secondLayer.shadowColor = [UIColor blueColor].CGColor;
    secondLayer.shadowRadius = 10;
    secondLayer.shadowOffset = CGSizeMake(0.0f, 5.0f);
    secondLayer.shadowOpacity = 0.8;

    
    _safariAry = @[firstLayer,secondLayer];
}

- (IBAction)buttonClick:(id)sender {
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.x"];
    animation.fromValue =@(0);
    animation.toValue = @(-M_PI*2/5);
    animation.duration = 1;
    animation.delegate = self;
    
    [animation setValue:@"safari" forKey:@"ID"];
    
    for (CALayer* layer in _safariAry) {
        [layer addAnimation:animation forKey:@"good"];
    }
}

#pragma mark - Clock Animation
-(void)initClockLayer{
//    
//    CAShapeLayer* clockbgLayer = [CAShapeLayer layer];
//    clockbgLayer.fillColor = [UIColor clearColor].CGColor;
//    clockbgLayer.strokeColor = [UIColor grayColor].CGColor;
//    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake((SCREENWIDTH-100)/5, (SCREENHEIGHT-100)*7/9, 100, 100) cornerRadius:50];
//    clockbgLayer.path = path.CGPath;
//    clockbgLayer.lineWidth = 2.0f;
//    
//    CAShapeLayer *hourLayer = [CAShapeLayer layer];
////    hourLayer.backgroundColor = [UIColor grayColor].CGColor;
//    hourLayer.frame = CGRectMake((SCREENWIDTH-100)/5+50, (SCREENHEIGHT-100)*7/9+30, 1, 20);
//    hourLayer.borderWidth = 1;
//    hourLayer.anchorPoint = CGPointMake(1 , 1);
////    hourLayer.path = [UIBezierPath bezierPathWithRect:CGRectMake((SCREENWIDTH-100)/5+50, (SCREENHEIGHT-100)*7/9+30, 1, 20)].CGPath;
//    [clockbgLayer addSublayer:hourLayer];
//    
//    CAShapeLayer *minusLayer = [CAShapeLayer layer];
//    minusLayer.path = [UIBezierPath bezierPathWithRect:CGRectMake((SCREENWIDTH-100)/5+50, (SCREENHEIGHT-100)*7/9+10, 1, 40)].CGPath;
//    minusLayer.strokeColor = [UIColor grayColor].CGColor;
////    minusLayer.anchorPoint = CGPointMake(0, 0);
////    [clockbgLayer addSublayer:minusLayer];
//    
//    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
//    animation.duration = 5;
//    animation.fromValue = @(0);
//    animation.toValue = @(M_PI/3);
//    [hourLayer addAnimation:animation forKey:nil];
//    
////    [hourLayer setTransform:CATransform3DMakeRotation(M_PI/5, 0, 0, 1)];
//    
////    [hourLayer setNeedsDisplay];
//    [self.view.layer addSublayer:clockbgLayer];
    
}

#pragma mark - GradientLayer
-(void)initGradientLayer{
    
    CAShapeLayer* backGroudLayer = [CAShapeLayer layer];
    UIBezierPath *bezierPath = [UIBezierPath bezierPathWithArcCenter:CGPointMake((SCREENWIDTH-100)*2/5, (SCREENHEIGHT-100)*7/9) radius:80 startAngle:-(M_PI*210/180) endAngle:M_PI*30/180 clockwise:YES];
    backGroudLayer.path = bezierPath.CGPath;
    backGroudLayer.strokeColor = [[UIColor grayColor] CGColor];
    backGroudLayer.fillColor = [[UIColor clearColor] CGColor];
    backGroudLayer.lineWidth = 10;
    backGroudLayer.opacity = 0.2;
    backGroudLayer.lineCap = kCALineCapRound;
    [self.view.layer addSublayer:backGroudLayer];
    
    CAShapeLayer* progressLayer = [CAShapeLayer layer];
    progressLayer.path = bezierPath.CGPath;
    progressLayer.fillColor = [UIColor clearColor].CGColor;
    progressLayer.strokeColor = [UIColor grayColor].CGColor;
    progressLayer.lineWidth = 8;
    progressLayer.strokeEnd = 0.1;
    progressLayer.lineCap = kCALineCapRound;
    [self.view.layer addSublayer:progressLayer];
    
    CALayer *layer = [CALayer layer];
   
    CAGradientLayer *gradientLayer2 = [CAGradientLayer layer];
    gradientLayer2.colors = @[(id)[UIColor redColor].CGColor,(id)[UIColor yellowColor].CGColor,(id)[UIColor blueColor].CGColor,(id)[UIColor greenColor].CGColor];
    gradientLayer2.frame = CGRectMake((SCREENWIDTH-100)*2/5-90, (SCREENHEIGHT-100)*7/9-90,90,180);
    gradientLayer2.startPoint = CGPointMake(0.5, 1);
    gradientLayer2.endPoint = CGPointMake(0.5, 0);
    
    CAGradientLayer *gradientLayer1 = [CAGradientLayer layer];
    gradientLayer1.colors = @[(id)[UIColor redColor].CGColor,(id)[UIColor blueColor].CGColor,(id)[UIColor greenColor].CGColor];
    gradientLayer1.frame = CGRectMake((SCREENWIDTH-100)*2/5, (SCREENHEIGHT-100)*7/9-90,90,180);
    gradientLayer1.startPoint = CGPointMake(0.5, 0);
    gradientLayer1.endPoint = CGPointMake(0.5, 1);
    
    [layer addSublayer:gradientLayer1];
    [layer addSublayer:gradientLayer2];
    
    [layer setMask:progressLayer];
    [self.view.layer addSublayer:layer];
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    animation.fromValue = @(0.1);
    animation.toValue = @(0.95);
    animation.duration = 1;
    animation.repeatCount = INFINITY;
    animation.autoreverses = YES;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    [progressLayer addAnimation:animation forKey:nil];
    
}

#pragma mark - Animation Delegate
- (void)animationDidStop:(CABasicAnimation *)anim finished:(BOOL)flag
{
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    
    if ([[anim valueForKey:@"ID"] isEqualToString:@"safari"]) {
        for (CALayer* layer in _safariAry) {
            [layer setTransform:CATransform3DMakeRotation(-M_PI*2/5, 1, 0, 0)];
        }
    }
    
    [CATransaction commit];
}


@end
