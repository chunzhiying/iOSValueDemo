//
//  AddOverlayViewController.m
//  VideoEditingPart2
//
//  Created by Abdul Azeem Khan on 1/24/13.
//  Copyright (c) 2013 com.datainvent. All rights reserved.
//

#import "AddOverlayViewController.h"

@interface AddOverlayViewController ()

@end

@implementation AddOverlayViewController

- (IBAction)loadAsset:(id)sender {
    [self startMediaBrowserFromViewController:self usingDelegate:self];
}

- (IBAction)generateOutput:(id)sender {
  [self videoOutput];
}

- (void)applyVideoEffectsToComposition:(AVMutableVideoComposition *)composition size:(CGSize)size
{
    UIImage *overImage = nil;
    switch (_frameSelectSegment.selectedSegmentIndex) {
        case 0:
            overImage = [UIImage imageNamed:@"Frame-1.png"];
            break;
        case 1:
            overImage = [UIImage imageNamed:@"Frame-2.png"];
            break;
        case 2:
            overImage = [UIImage imageNamed:@"Frame-3.png"];
            break;
    }
    
    CALayer *overLayer = [CALayer layer];
    overLayer.contents = (__bridge id)([overImage CGImage]);
    overLayer.frame = CGRectMake(0, 0, size.width/2, size.height/2);
    
    CALayer *videoLayer = [CALayer layer];
    videoLayer.frame = CGRectMake(0, 0, size.width, size.height);
    
    CALayer *parentLayer = [CALayer layer];
    parentLayer.frame = CGRectMake(0, 0, size.width, size.height);
    [parentLayer addSublayer:videoLayer];
    [parentLayer addSublayer:overLayer];
    
    composition.animationTool = [AVVideoCompositionCoreAnimationTool videoCompositionCoreAnimationToolWithPostProcessingAsVideoLayer:videoLayer inLayer:parentLayer];
    
}

@end
