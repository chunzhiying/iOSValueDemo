//
//  AddAnimationViewController.m
//  VideoEditingPart2
//
//  Created by Abdul Azeem Khan on 1/24/13.
//  Copyright (c) 2013 com.datainvent. All rights reserved.
//

#import "AddAnimationViewController.h"

@interface AddAnimationViewController ()

@end

@implementation AddAnimationViewController

- (IBAction)loadAsset:(id)sender {
    [self startMediaBrowserFromViewController:self usingDelegate:self];
}

- (IBAction)generateOutput:(id)sender {
  [self videoOutput];
}

- (void)applyVideoEffectsToComposition:(AVMutableVideoComposition *)composition size:(CGSize)size
{
    UIImage *animationImage = [UIImage imageNamed:@"star.png"];
    CALayer *starLayer = [CALayer layer];
    starLayer.contents = (__bridge id)(animationImage.CGImage);
    starLayer.frame = CGRectMake(50, 50, 128, 128);
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
    animation.fromValue = @(0);
    animation.toValue = @(2*M_PI);
    animation.duration = 3;
    animation.repeatCount = 2;
    animation.beginTime = AVCoreAnimationBeginTimeAtZero;
    
//    CABasicAnimation *animation =
//    [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
//    animation.duration=2.0;
//    animation.repeatCount=5;
//    animation.autoreverses=YES;
//    // rotate from 0 to 360
//    animation.fromValue=[NSNumber numberWithFloat:0.0];
//    animation.toValue=[NSNumber numberWithFloat:(2.0 * M_PI)];
//    animation.beginTime = AVCoreAnimationBeginTimeAtZero;

    
    CALayer *parentLayer = [CALayer layer];
    CALayer *videoLayer = [CALayer layer];
    parentLayer.frame = CGRectMake(0, 0, size.width, size.height);
    videoLayer.frame = parentLayer.frame;
    
    [videoLayer addAnimation:animation forKey:nil];
    
    
    [parentLayer addSublayer:videoLayer];
    [parentLayer addSublayer:starLayer];
    
    composition.animationTool = [AVVideoCompositionCoreAnimationTool videoCompositionCoreAnimationToolWithPostProcessingAsVideoLayer:videoLayer inLayer:parentLayer];
    
    
}

@end
