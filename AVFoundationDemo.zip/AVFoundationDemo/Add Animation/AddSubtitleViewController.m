//
//  AddSubtitleViewController.m
//  VideoEditingPart2
//
//  Created by Abdul Azeem Khan on 3/19/13.
//  Copyright (c) 2013 com.datainvent. All rights reserved.
//

#import "AddSubtitleViewController.h"

@interface AddSubtitleViewController ()

@end

@implementation AddSubtitleViewController

- (IBAction)loadAsset:(id)sender {
    [self startMediaBrowserFromViewController:self usingDelegate:self];
}

- (IBAction)generateOutput:(id)sender {
    [self videoOutput];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)applyVideoEffectsToComposition:(AVMutableVideoComposition *)composition size:(CGSize)size
{
    CATextLayer *textLayer = [CATextLayer layer];
    textLayer.foregroundColor = [[UIColor yellowColor] CGColor];
    textLayer.fontSize = 30;
    textLayer.string = @"AVFoundation Demo";
    textLayer.frame = CGRectMake(0, 0, size.width, 100);
    
    CALayer *videoLayer = [CALayer layer];
    videoLayer.frame = CGRectMake(0, 0, size.width, size.height);
    
    CALayer *parentLayer = [CALayer layer];
    parentLayer.frame = CGRectMake(0, 0, size.width, size.height);
    
    
    CABasicAnimation *rotation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.x"];
    rotation.fromValue = @(0);
    rotation.toValue = @(2*M_PI);
    rotation.duration = 3;
    [textLayer addAnimation:rotation forKey:nil];

    
    [parentLayer addSublayer:videoLayer];
    [parentLayer addSublayer:textLayer];
    
    composition.animationTool = [AVVideoCompositionCoreAnimationTool videoCompositionCoreAnimationToolWithPostProcessingAsVideoLayer:videoLayer inLayer:parentLayer];
    
}


@end
