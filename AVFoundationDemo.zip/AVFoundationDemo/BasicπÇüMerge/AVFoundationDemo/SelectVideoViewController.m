//
//  SelectVideoViewController.m
//  AVFoundationDemo
//
//  Created by chenzy on 15/7/21.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "SelectVideoViewController.h"
#import <MediaPlayer/MediaPlayer.h>
#import <MobileCoreServices/MobileCoreServices.h>

@interface SelectVideoViewController () <UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@end

@implementation SelectVideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Custom Method
- (BOOL)startMediaBrowserFromViewController:(UIViewController*)controller
                                   delegate:(id<UIImagePickerControllerDelegate,UINavigationControllerDelegate>)delegate
{
    if (([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum] == NO)
        || (delegate == nil)
        || (controller == nil)) {
        return NO;
    }
    
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
    picker.mediaTypes = @[(NSString*)kUTTypeMovie]; //只会看见视频

    picker.allowsEditing = YES;
    picker.delegate = delegate;
    
    [controller presentViewController:picker animated:YES completion:nil];
    
    return YES;
}

#pragma mark -  IBAction
- (IBAction)clickPlayVideo:(id)sender {
    [self startMediaBrowserFromViewController:self delegate:self];
}

#pragma mark - UIImagePickerController Delegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
    MPMoviePlayerViewController *theMovie = [[MPMoviePlayerViewController alloc]
                                         initWithContentURL:[info objectForKey:UIImagePickerControllerMediaURL]];
    [picker presentMoviePlayerViewControllerAnimated:theMovie];

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
