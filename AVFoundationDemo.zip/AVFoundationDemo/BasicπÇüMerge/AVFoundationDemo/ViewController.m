//
//  ViewController.m
//  AVFoundationDemo
//
//  Created by chenzy on 15/7/20.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "ViewController.h"
@import AVFoundation;

@interface ViewController () <AVCaptureMetadataOutputObjectsDelegate>{
    
    __weak IBOutlet UILabel *_label;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // 定义摄像头位输入
    AVCaptureSession *session = [[AVCaptureSession alloc] init];
    
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    NSError* error = nil;
    
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
    
    if (input) {
        [session addInput:input];
    }else{
        NSLog(@"error");
        return;
    }
    
    // 输出会话
    AVCaptureVideoPreviewLayer* previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:session];
    previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    previewLayer.bounds = self.view.bounds;
    previewLayer.position = CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds));
    
    AVCaptureVideoDataOutput *ouput = [[AVCaptureVideoDataOutput alloc] init];
    
    
    [self.view.layer addSublayer:previewLayer];
    
    [session startRunning];
    
//    // 捕获元数据
//    AVCaptureMetadataOutput *output = [[AVCaptureMetadataOutput alloc] init];
//    [session addOutput:output];
//    NSLog(@"%@", [output availableMetadataObjectTypes]);
//    
//    // 注册查找的二维码类型
//    [output setMetadataObjectTypes:@[AVMetadataObjectTypeQRCode]];
//    [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//#pragma mark - AVCaptureMetadataOutputObjectsDelegate
//- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection{
//    
//    for (AVMetadataObject* metaData in metadataObjects) {
//        if ([metaData.type isEqualToString:AVMetadataObjectTypeQRCode]) {
//            AVMetadataMachineReadableCodeObject *transformed = (AVMetadataMachineReadableCodeObject *)metaData;
//            _label.text = [transformed stringValue];
//        }
//    }
//    
//}

@end
