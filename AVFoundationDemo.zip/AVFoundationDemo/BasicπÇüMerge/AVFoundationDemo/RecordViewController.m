//
//  RecordViewController.m
//  AVFoundationDemo
//
//  Created by chenzy on 15/7/21.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "RecordViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import <MediaPlayer/MediaPlayer.h>

@interface RecordViewController () <UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@end

@implementation RecordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - IBAction
- (IBAction)clickRecordVideo:(id)sender {
    UIImagePickerController *camera = [[UIImagePickerController alloc] init];
    camera.mediaTypes = @[(NSString*)kUTTypeMovie];
    camera.sourceType = UIImagePickerControllerSourceTypeCamera;
    
    camera.delegate = self;
    [self presentViewController:camera animated:YES completion:nil];
}

#pragma mark - UIImagePickerController Delegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
    NSString *mediaType = info[UIImagePickerControllerMediaType];
    if (CFStringCompare(kUTTypeMovie, (__bridge_retained CFStringRef)mediaType, 0)) {
        
        NSString *moviePath = [info[UIImagePickerControllerMediaURL] path];
        if (UIVideoAtPathIsCompatibleWithSavedPhotosAlbum(moviePath)) {
            UISaveVideoAtPathToSavedPhotosAlbum(moviePath, self, nil, nil);
        }
        
        
    }
}

@end
