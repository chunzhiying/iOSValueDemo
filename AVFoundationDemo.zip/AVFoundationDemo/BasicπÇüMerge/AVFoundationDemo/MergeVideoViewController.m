//
//  MergeVideoViewController.m
//  AVFoundationDemo
//
//  Created by chenzy on 15/7/21.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "MergeVideoViewController.h"
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <AssetsLibrary/AssetsLibrary.h>

@interface MergeVideoViewController () <UIImagePickerControllerDelegate,UINavigationControllerDelegate,MPMediaPickerControllerDelegate> {
    AVAsset *_firstAsset;
    AVAsset *_secondAsset;
    AVAsset *_audioAsset;
    
    BOOL _isFirstAssetSeleted;
    
    __weak IBOutlet UIActivityIndicatorView *_ActivityIndicator;
    
}

@end

@implementation MergeVideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _ActivityIndicator.hidden = YES;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Custom Method
- (void)startMediaBrowserFromViewController:(UIViewController*)viewController
                              usingDelegate: (id<UIImagePickerControllerDelegate, UINavigationControllerDelegate>)delegate
{
    UIImagePickerController *pickerController = [[UIImagePickerController alloc] init];
    pickerController.mediaTypes = @[(NSString*)kUTTypeMovie];
    pickerController.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
    pickerController.delegate   = delegate;
    
    [viewController presentViewController:pickerController animated:YES completion:nil];
    
}

- (void)mergeVideo{
    
    if (_firstAsset == nil || _secondAsset == nil || _audioAsset == nil) {
        [[[UIAlertView alloc] initWithTitle:@"提示" message:@"请完整输入视频和音频" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil] show];
        return;
    }
    
    AVMutableComposition *mixComposition = [[AVMutableComposition alloc] init];
    
    // video Track
    AVMutableCompositionTrack *videoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo
                                                                        preferredTrackID:kCMPersistentTrackID_Invalid];
    
    [videoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, _firstAsset.duration)
                        ofTrack:[[_firstAsset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]
                         atTime:kCMTimeZero error:nil];
    
    [videoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, _secondAsset.duration)
                        ofTrack:[[_secondAsset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0]
                         atTime:_firstAsset.duration error:nil];
    
    // Audio Track
    AVMutableCompositionTrack *audioTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio
                                                                        preferredTrackID:kCMPersistentTrackID_Invalid];
    
    [audioTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, CMTimeAdd(_firstAsset.duration, _secondAsset.duration))
                        ofTrack:[[_audioAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0]
                         atTime:kCMTimeZero error:nil];
    
    // Get Path
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *myPathDocs =  [documentsDirectory stringByAppendingPathComponent:
                             [NSString stringWithFormat:@"mergeVideo-%d.mov",arc4random() % 1000]];
    NSURL *url = [NSURL fileURLWithPath:myPathDocs];
    
    // Create Export
    AVAssetExportSession *exporter = [[AVAssetExportSession alloc] initWithAsset:mixComposition
                                                                      presetName:AVAssetExportPresetHighestQuality];
    
    exporter.outputURL = url;
    exporter.outputFileType = AVFileTypeQuickTimeMovie;
    exporter.shouldOptimizeForNetworkUse = YES;
    [exporter exportAsynchronouslyWithCompletionHandler:^{
        dispatch_async(dispatch_get_main_queue(), ^{
            [self exportDidFinish:exporter];
        });
    }];
    
}

- (void)exportDidFinish:(AVAssetExportSession*)session{
    if (session.status == AVAssetExportSessionStatusCompleted) {
        NSURL *ouputURL = session.outputURL;
        ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
        if ([library videoAtPathIsCompatibleWithSavedPhotosAlbum:ouputURL]) {
            [library writeVideoAtPathToSavedPhotosAlbum:ouputURL completionBlock:^(NSURL *assetURL, NSError *error){
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    [[[UIAlertView alloc] initWithTitle:@"提示"
                                                message:error ? @"save fail" : @"save sucess"
                                               delegate:nil cancelButtonTitle:@"确定"
                                      otherButtonTitles:nil] show];
                    
                });
                
            }];
        }
    }
    [_ActivityIndicator stopAnimating];
}

#pragma mark - IBAction
- (IBAction)loadAsset1:(id)sender {
    _isFirstAssetSeleted = YES;
    [self startMediaBrowserFromViewController:self usingDelegate:self];
}

- (IBAction)loadAsset2:(id)sender {
    _isFirstAssetSeleted = NO;
    [self startMediaBrowserFromViewController:self usingDelegate:self];
}

- (IBAction)loadAudio:(id)sender {
    MPMediaPickerController *mediaPicker = [[MPMediaPickerController alloc] initWithMediaTypes:MPMediaTypeAny];
    mediaPicker.delegate = self;
    mediaPicker.prompt = @"Select Audio";
    [self presentViewController:mediaPicker animated:YES completion:nil];
}

- (IBAction)mergeAndSaveVideo:(id)sender {
    _ActivityIndicator.hidden = NO;
    [_ActivityIndicator startAnimating];
    [self mergeVideo];
}

#pragma mark - MediaPickerController Delegate
- (void)mediaPicker:(MPMediaPickerController *)mediaPicker didPickMediaItems:(MPMediaItemCollection *)mediaItemCollection{
    
    NSArray *ary = [mediaItemCollection items];
    if (ary.count > 0) {
        
        NSURL *songURL = [((MPMediaItem*)[ary firstObject]) valueForProperty:MPMediaItemPropertyAssetURL];
        _audioAsset = [AVAsset assetWithURL:songURL];
        
        [[[UIAlertView alloc] initWithTitle:@"提示" message:@"audio Asset Load" delegate:nil
                          cancelButtonTitle:@"确定" otherButtonTitles:nil] show];
        
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)mediaPickerDidCancel:(MPMediaPickerController *)mediaPicker{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - VideoPickerController Delegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    [[[UIAlertView alloc] initWithTitle:@"提示"
                                message: _isFirstAssetSeleted ? @"Asset 1 Load" : @"Asset 2 Load"
                               delegate:nil
                      cancelButtonTitle:@"确定"
                      otherButtonTitles:nil] show];
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
    if (_isFirstAssetSeleted) {
        _firstAsset  = [AVAsset assetWithURL:info[UIImagePickerControllerMediaURL]];
    }else {
        _secondAsset = [AVAsset assetWithURL:info[UIImagePickerControllerMediaURL]];
    }
    
}

@end
