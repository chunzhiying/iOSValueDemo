//
//  SelectVideoViewController.h
//  AVFoundationDemo
//
//  Created by chenzy on 15/7/21.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "ViewController.h"

@interface SelectVideoViewController : UIViewController

@end
