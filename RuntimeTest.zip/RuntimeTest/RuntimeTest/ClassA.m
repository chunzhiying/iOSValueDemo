
//
//  ClassA.m
//  RuntimeTest
//
//  Created by chenzy on 15/3/26.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "ClassA.h"

@implementation ClassA

-(void)oldMethod{
    NSLog(@"class A oldMethod!!");
}

@end
