//
//  ClassA.h
//  RuntimeTest
//
//  Created by chenzy on 15/3/26.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ClassA : NSObject{
    int a;
}

@property(strong)NSString *bb;

-(void)oldMethod;

@end
