//
//  ViewController.m
//  RuntimeTest
//
//  Created by chenzy on 15/3/26.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "ViewController.h"
#import "ClassA.h"
#import <objc/runtime.h>

@interface ViewController (){
    ClassA *classA;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    classA = [ClassA new];
    
    //动态给ClassA添加方法
    class_addMethod([ClassA class],@selector(newMethod),(IMP)addMethod,nil);
    [classA performSelector:@selector(newMethod) withObject:nil];
    
    [classA oldMethod];
    //将ClassA中的oldMethod方法的实现修改为replaceMethod
    class_replaceMethod([ClassA class], @selector(oldMethod), (IMP)replaceMethod, nil);
    [classA oldMethod];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//获取属性
- (IBAction)gainProperty:(id)sender {
    u_int count;
    objc_property_t* properties = class_copyPropertyList([ClassA class], &count);
    for (int i=0; i<count; i++) {
        const char* propertyName = property_getName(properties[i]);
        NSString* propertyString = [NSString stringWithCString:propertyName encoding:NSUTF8StringEncoding];
        NSLog(@"%@",propertyString);
    }
}

//获取方法
- (IBAction)getMethod:(id)sender {
    u_int count;
    Method *methods = class_copyMethodList([ClassA class], &count);
    for (int i=0; i<count; i++) {
        const char* methodName = method_getName(methods[i]);
        NSString* methodString = [NSString stringWithCString:methodName encoding:NSUTF8StringEncoding];
        NSLog(@"%@",methodString);
    }
}

//创建一个新类
- (IBAction)createNewClass:(id)sender {
    [self.view viewWithTag:999].hidden = YES;
    Class ClassB = objc_allocateClassPair([NSObject class], "ClassB", 0);
    BOOL flag = class_addIvar(ClassB, "_B", sizeof(NSString*), log2(sizeof(NSString*)), @encode(NSString*));
    if (flag) {
        NSLog(@"ClassB 添加成员变量成功");
    }
    objc_registerClassPair(ClassB);
    u_int count;
    Ivar* ivarList = class_copyIvarList(ClassB, &count);
    NSString* ivarName = [NSString stringWithCString:ivar_getName(ivarList[0]) encoding:NSUTF8StringEncoding];
    NSLog(@"ClassB 的成员变量;%@",ivarName);
}

#pragma mark - classA
void addMethod(id self, SEL _cmd){
    NSLog(@"%s",__func__);
}

void replaceMethod(id self, SEL _cmd){
     NSLog(@"%s",__func__);
}


@end
