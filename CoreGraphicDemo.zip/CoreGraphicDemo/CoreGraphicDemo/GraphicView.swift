//
//  GraphicView.swift
//  CoreGraphicDemo
//
//  Created by chenzy on 15/7/31.
//  Copyright (c) 2015年 YY. All rights reserved.
//

import UIKit

@IBDesignable class GraphicView: UIView {

    @IBInspectable var startColor: UIColor = UIColor.redColor()
    @IBInspectable var endColor: UIColor = UIColor.whiteColor()
    
    var graphPoints: [Int] = [4, 3, 5, 6, 1, 8, 2]
    
    override func drawRect(rect: CGRect) {
        
        let width = rect.width
        let height = rect.height
        
        // 使用core graphic来画圆角
        var path = UIBezierPath(roundedRect: rect, byRoundingCorners: UIRectCorner.AllCorners, cornerRadii: CGSize(width: 8.0, height: 8.0))
        path.addClip()
        
        // 使用core graphic来画渐变背景
        let context = UIGraphicsGetCurrentContext()
        
        let colors = [startColor.CGColor, endColor.CGColor]
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let colorLocations: [CGFloat] = [0, 1.0]
        
        let gradient = CGGradientCreateWithColors(colorSpace, colors, colorLocations)
        
        var startPoint = CGPoint.zeroPoint
        var endPoint = CGPoint(x: 0, y: self.bounds.height)
        CGContextDrawLinearGradient(context, gradient, startPoint, endPoint, 0)
        
        // 计算点的x坐标 每一个margin
        let margin: CGFloat = 20.0
        var columnXPoint = { (column:Int) -> CGFloat in
            let spacer = (width - margin*2 - 4) / CGFloat(self.graphPoints.count - 1)
            var x: CGFloat = CGFloat(column) * spacer
            x += margin + 2
            return x
        }
        
        // 计算点得y坐标
        let topBorder:CGFloat = 60
        let bottomBorder:CGFloat = 50
        let graphHeight = height - topBorder - bottomBorder
        let maxValue = maxElement(graphPoints)
        var columnYPoint = { (graphPoint:Int) -> CGFloat in
            var y:CGFloat = CGFloat(graphPoint) /
                CGFloat(maxValue) * graphHeight
            y = graphHeight + topBorder - y // Flip the graph
            return y
        }
        
        // 画折线主体
        UIColor.whiteColor().setFill()
        UIColor.whiteColor().setStroke()
        
        var graphPath = UIBezierPath()
        graphPath.moveToPoint(CGPoint(x: columnXPoint(0), y: columnYPoint(graphPoints[0])))
        
        for i in 1..<graphPoints.count {
            graphPath.addLineToPoint(CGPoint(x: columnXPoint(i), y: columnYPoint(graphPoints[i])))
        }
        
        // 画折线阴影
        var clippingPath = graphPath.copy() as! UIBezierPath

        clippingPath.addLineToPoint(CGPoint(x: columnXPoint(graphPoints.count - 1), y: height))
        clippingPath.addLineToPoint(CGPoint(x: columnXPoint(0), y: height))
        clippingPath.closePath()
        clippingPath.addClip() //沿边缘切割
        
        let highestYPoint = columnYPoint(maxValue)
        startPoint = CGPoint(x: margin, y: highestYPoint)
        endPoint = CGPoint(x: margin, y: self.bounds.height)
        
        CGContextDrawLinearGradient(context, gradient, startPoint, endPoint, 0)
        
        graphPath.lineWidth = 2.0
        graphPath.stroke()
        
        // 加粗转折点
        for i in 0..<graphPoints.count {
            let point = CGPoint(x: columnXPoint(i), y: columnYPoint(graphPoints[i]))

            let circle = UIBezierPath(ovalInRect: CGRectMake(point.x-2.5, point.y-2.5, 5, 5))
            circle.fill()
        }
        
//        var kPath = UIBezierPath()
//        kPath.moveToPoint(CGPoint(x: 10, y: bounds.height / 4))
//        kPath.addLineToPoint(CGPoint(x: bounds.width / 2, y: bounds.height * 3 / 4))
//        kPath.addLineToPoint(CGPoint(x: bounds.width - 10, y: bounds.height / 5))
//        
//        var shapeLayer = CAShapeLayer()
//        shapeLayer.path = kPath.CGPath
//        shapeLayer.strokeColor = UIColor.yellowColor().CGColor
//        shapeLayer.fillColor = UIColor.clearColor().CGColor
//        layer.addSublayer(shapeLayer)
        
    }
    
}
