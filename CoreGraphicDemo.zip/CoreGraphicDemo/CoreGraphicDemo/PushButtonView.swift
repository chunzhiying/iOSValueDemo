//
//  PushButtonView.swift
//  CoreGraphicDemo
//
//  Created by chenzy on 15/7/29.
//  Copyright (c) 2015年 YY. All rights reserved.
//

import UIKit

@IBDesignable

class PushButtonView: UIButton {
    
    @IBInspectable var fillColor: UIColor = UIColor.greenColor()
    @IBInspectable var isAddButton: Bool = true
    
    override func drawRect(rect: CGRect) {
        var path = UIBezierPath(ovalInRect: rect)
        fillColor.setFill()
        path.fill()
        
        let plusHeight: CGFloat = 3.0
        let plusWidth: CGFloat = min(bounds.size.width, bounds.size.height) * 0.6
        
        var plusPah1 = UIBezierPath()
        plusPah1.lineWidth = plusHeight
        
        // 0.5 for anti-aliasing
        plusPah1.moveToPoint(CGPoint(x: bounds.width/2 - plusWidth/2 + 0.5, y: bounds.height/2 + 0.5))
        plusPah1.addLineToPoint(CGPoint(x: bounds.width/2 + plusWidth/2 + 0.5, y: bounds.height/2 + 0.5))
        
        UIColor.whiteColor().setStroke()
        plusPah1.stroke()
        
        if isAddButton {
            var plusPath2 = UIBezierPath()
            plusPath2.lineWidth = plusHeight
            
            plusPath2.moveToPoint(CGPoint(x: bounds.width/2 , y: bounds.height/2 - plusWidth/2))
            plusPath2.addLineToPoint(CGPoint(x: bounds.width/2, y: bounds.height/2 + plusWidth/2))
            
            plusPath2.stroke()
        }
     
        
    }
    
}
