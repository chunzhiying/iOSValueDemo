//
//  ViewController.swift
//  CoreGraphicDemo
//
//  Created by chenzy on 15/7/29.
//  Copyright (c) 2015年 YY. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var counterView: CounterView!
    @IBOutlet weak var graphicView: GraphicView!
    
    var isGraphicViewShowing = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func containerViewClick(sender: AnyObject) {
        
//        var transitionAni = CATransition()
//        transitionAni.type = kCATransitionFade
//        transitionAni.duration = 0.5
//
//        var rotationAni = CABasicAnimation(keyPath: "transform.rotation.y")
//        rotationAni.fromValue = 0
//        rotationAni.toValue = M_PI
//        rotationAni.duration = 0.5
//        
//        var animationGroup = CAAnimationGroup()
//        animationGroup.animations = [transitionAni,rotationAni]
//        animationGroup.duration = 0.5
//        
//        if isGraphicViewShowing {
//            
//            counterView.hidden = false
//            graphicView.hidden = true
//            isGraphicViewShowing = false
//            
//        } else {
//            
//            counterView.hidden = true
//            graphicView.hidden = false
//            isGraphicViewShowing = true
//            
//        }
//        
//        containerView.layer.addAnimation(animationGroup, forKey: nil)
//        
//   
        if isGraphicViewShowing {
            
            UIView.transitionFromView(graphicView, toView: counterView, duration: 0.5,
                options: UIViewAnimationOptions.TransitionFlipFromLeft | UIViewAnimationOptions.ShowHideTransitionViews,
                completion: nil)
            
        } else {
            
            UIView.transitionFromView(counterView, toView: graphicView, duration: 0.5,
                options: UIViewAnimationOptions.TransitionFlipFromRight | UIViewAnimationOptions.ShowHideTransitionViews,
                completion: nil)
            
        }
        
        isGraphicViewShowing = !isGraphicViewShowing
        
        
    }


}

