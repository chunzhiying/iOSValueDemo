//
//  ViewController.h
//  MPMovieDemo
//
//  Created by chenzy on 15/4/28.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

