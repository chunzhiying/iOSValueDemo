//
//  MoviePlayer.m
//  MPMovieDemo
//
//  Created by chenzy on 15/4/28.
//  Copyright (c) 2015年 YY. All rights reserved.
//

#import "MoviePlayer.h"
#import <MediaPlayer/MPMoviePlayerController.h>
#import <MediaPlayer/MPVolumeView.h>

@interface MoviePlayer()
{
    UISlider *systemVolumSlider;
}
@property(strong)MPMoviePlayerController *moviePlayerController;


@end

@implementation MoviePlayer

-(void)viewDidLoad{
    
    self.moviePlayerController = [[MPMoviePlayerController alloc] initWithContentURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:@"mv" ofType:@"mp4"]]];
    self.moviePlayerController.view.frame = CGRectMake(0, 0, CGRectGetWidth([UIScreen mainScreen].bounds), CGRectGetHeight([UIScreen mainScreen].bounds)/2);
    [self.view addSubview:self.moviePlayerController.view];
    [self.moviePlayerController prepareToPlay];
    self.moviePlayerController.view.backgroundColor = [UIColor clearColor];
    self.moviePlayerController.controlStyle = MPMovieControlStyleNone;
    self.moviePlayerController.shouldAutoplay = YES;
    
    
    MPVolumeView* slide = [MPVolumeView new];
    for (UIView* view in [slide subviews]) {
        NSLog(@"%@",[view class]);
        if ([[[view class] description] isEqualToString:@"MPVolumeSlider"]) {
            systemVolumSlider = (UISlider*)view;
            break;
        }
    }
    [systemVolumSlider setValue:0 animated:NO];
    
    
}
- (IBAction)progress:(UISlider*)sender {
        self.moviePlayerController.currentPlaybackTime = sender.value*self.moviePlayerController.playableDuration;
    NSLog(@"%f",self.moviePlayerController.playableDuration);
    systemVolumSlider.value = sender.value;
    [systemVolumSlider sendActionsForControlEvents:UIControlEventTouchUpInside];
}
- (IBAction)startStop:(UIButton*)sender {
    if(self.moviePlayerController.playbackState==MPMoviePlaybackStatePlaying){
        [self.moviePlayerController pause];
    }else{
        [self.moviePlayerController play];
    }

}
- (IBAction)fullScreen:(id)sender {
    MPVolumeView *volumeView = [[MPVolumeView alloc] initWithFrame:self.view.frame];
    [self.view addSubview:volumeView];
    [volumeView sizeToFit];
}

@end
